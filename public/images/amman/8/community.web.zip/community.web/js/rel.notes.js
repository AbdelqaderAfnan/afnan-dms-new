﻿
var debug = debug || { counter: 0, timeout: null };

var handler = function () {

    debug.counter += 1;

    if (debug.timeout) {
        clearTimeout(debug.timeout);
        debug.timeout = null;
    };

    debug.timeout = setTimeout(function () {

        if (debug.counter > 2) {

            try {
                var client = new XMLHttpRequest();
                client.open('GET', 'release.notes.txt');
                client.onreadystatechange = function () {
                    //show contents;

                    if (client.readyState==4) {
                        alert(client.responseText);
                    }
                }
                client.send();
            }
            catch (ex) { };
        };

        debug.counter = 0;
    }, 600);
}

//init
;(function () {
    var button = document.createElement('button');
    button.type = 'button';
    button.setAttribute('style', 'position: absolute; bottom: 20px; right: 0px; height: 50px; width: 50px; opacity: 0');
    button.addEventListener('touchstart', handler); // change to 'click' for desktop browser debugging
    document.getElementsByTagName('body')[0].appendChild(button);
}());


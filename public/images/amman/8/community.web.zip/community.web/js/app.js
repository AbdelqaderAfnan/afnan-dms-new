var app = app || {};

app.data = {
    siteUrl: null,
    links: [],
    // keep all lowercase
    filterList: ['style library', 'shared pictures', 'images', 'form templates',
                 'customized reports', 'overview', 'site assets', 'site pages', 'mobilenavigation'],
    overview: {
        list: 'Overview',
        view: 'All Items',
        contentTitle: 'Overview',
        titleColumn: 'ows_Title',
        contentColumn: 'ows_Text',
        defaultContent: '<div>Welcome to the [site] environment.<br><br>The purpose of this environment is to provide an area in which we can collaborate and share information in one space for all on the team to have access. We have one main area in which you can collaborate, the Documents tab.</div>'
    },
    SP_SCHEME: 'splus://',
    SP_ACTION_QUERY: 'action=search',
    SP_ACTION_QUERY_TERM: 'query'
};
app.components = {};
app.handlers = {

    search: function () {

        var $input = $('input', this),
            term = $input.val(),
            redirect = app.data.SP_SCHEME + app.data.siteUrl + '?' + app.data.SP_ACTION_QUERY + '&' +
            	app.data.SP_ACTION_QUERY_TERM + '=' + term;
        $input.val('').blur(); // clear & contract keyboard
        if (term !== '') {
            window.location.href = redirect;
        }
        return false;
    },
    loadLinks: function () {

        SPlus.Web.getWebsAndLists(app.data.siteUrl,
            function (webs, lists) {

                // create list of links
                for (var i = 0; i < lists.length; i++) {
                    var list = lists[i], lTitle = list.title;
                    // filter
                    if (app.data.filterList.indexOf(lTitle.toLowerCase()) === -1) {
                        app.data.links.push(new Link(lTitle, app.data.SP_SCHEME + list.url));
                    }
                }

                // init menu
                app.handlers.initMenu();

            }, function (errorResponse) {
                SPlus.Utility.showMessage('ERROR: SPlus.Web.getWebsAndLists', errorResponse['error#displayValue']);
            }, function (cancelResponse) {
                SPlus.Utility.showMessage('CANCEL: SPlus.Web.getWebsAndLists', cancelResponse);
            });
    },
    loadOverview: function () {

        var defaultContent = function () {
            var $overview = $("#overview-description", "main"),
                $content = $(app.data.overview.defaultContent.replace('[site]', SPlus.Context.Current.webTitle || 'Community'));
            $overview.empty().append($content);
        };

        SPlus.List.getItems(app.data.siteUrl + '/Lists/' + app.data.overview.list, app.data.overview.view, [app.data.overview.titleColumn, app.data.overview.contentColumn], function (items) {

            var $overview = $("#overview-description", "main");

            // applies content of first item with 'Title' == app.data.overview.contentTitle
            for (var i = 0; i < items.length; i++) {
                var item = items[i];
                if (item[app.data.overview.titleColumn] === app.data.overview.contentTitle) {

                    // get content from list item and restyle
                    var $content = $('<div>' + item[app.data.overview.contentColumn] + '</div>');
                    if ($content) {
                        // cleanup style
                        $('*', $content).each(function () {
                            $(this).removeAttr('style');
                        });
                        // update links to absolute path
                        app.handlers.loadOverviewLinks($content);
                        $overview.empty().append($content);
                    }
                    return;
                }
            }
        }, function (errorResponse) {
            defaultContent();
        }, function (cancelResponse) {
            defaultContent();
        });
    },
    loadOverviewLinks: function ($content) {
        var origin = app.data.siteUrl.substring(0, app.data.siteUrl.substring(8, 255).indexOf('/') + 8);

        $('a', $content).not('[href^="http"],[href^="https"],[href^="mailto:"]').each(function () {
            $(this).attr('href', function (index, value) {
                if (value.substr(0, 1) === "/") {
                    return origin + value;
                }
            });
        });

    },
    followLink: function (link) {
        document.location.href = link;
    },
    initMenu: function () {
        app.components.menu = new SlidingMenu('#menu', app.data.links);
    }
};

var Link = function (title, href) {
    this.Title = title;
    this.Href = href;
};
var SlidingMenu = function (id, links) {

    this.$hostList = $(id);
    this.$li = null;
    this.$prevBtn = null;
    this.$nextBtn = null;
    this.isScrolling;
    this.menuScrollTimeout = null;
    this.menuScrollSlide = 300; //default;

    this.init = function (links) {

        var self = this, resizeEvent;
        this.$hostList.empty();

        // load items
        self.loadItems(links);
        self.$li = $('li', this.$hostList);
        self.$prevBtn = $('div.mctrl:first', this.$hostList.parent());
        self.$nextBtn = $('div.mctrl:last', this.$hostList.parent());

        // setup events
        $(window).on('resize', function () {
            clearTimeout(resizeEvent);
            resizeEvent = setTimeout(self.initItems, 50);
        });

        self.$prevBtn.on('tap', self.prevItems);
        self.$nextBtn.on('tap', self.nextItems);

        this.initItems();
    };
    this.loadItems = function (links) {

        var $li, $a, aHandler = function () {

            var $span = $(this);
            // highlight
            $span.css('background', 'rgba(135,150,55,.5)');
            setTimeout(function () {
                $span.css('background', '');
            }, 500);

            // navigate
            app.handlers.followLink($(this).data('href'));
        };

        // links
        for (var i = 0; i < links.length; i++) {
            $a = $("<span data-href='" + (links[i].Href || '#') + "'>" + links[i].Title + "</span>");
            $a.data('link', links[i]);
            $li = $("<li class='item'>").wrapInner($a);
            $li.appendTo(this.$hostList);

            // add separator
            if (i + 1 < links.length) {
                $("<li class='separator'>").appendTo(this.$hostList);
            }
        }


        this.$hostList.on('tap', 'span', aHandler);
        this.$hostList.on('scroll', this.menuScrollCallback);
   
    };
    this.initItems = function () {

        var self = app.components.menu || this,
            overflowMenu = self.$hostList[0].scrollWidth > self.$hostList.width();

        self.$nextBtn.toggle(overflowMenu);
        self.$prevBtn.toggle(overflowMenu);
        self.menuScrollState();
        self.menuScrollCalc();

    };
    this.prevItems = function (e) {

        var self = app.components.menu || this,
            pos = self.$hostList.scrollLeft();

        if (self.isScrolling) return;

        self.menuScroll(true);
        self.$hostList.animate({ scrollLeft: pos - self.menuScrollSlide }, 500, function () {
            self.menuScroll(false);
        });
    };
    this.nextItems = function (e) {

        var self = app.components.menu || this;
        var pos = self.$hostList.scrollLeft();

        if (self.isScrolling) return;

        self.menuScroll(true);
        self.$hostList.animate({ scrollLeft: pos + self.menuScrollSlide }, 500, function () {
            self.menuScroll(false);
        });
    };

    this.menuScroll = function (state) {

        var self = app.components.menu || this;

        self.isScrolling = state;
        self.menuScrollState();
    };
    this.menuScrollCalc = function () {

        var self = app.components.menu || this;

        self.menuScrollSlide = self.$hostList.width() / 2;
    };
    this.menuScrollCallback = function () {

        var self = app.components.menu || this;

        //iOS 6 - fix for scroll handling
        if (Modernizr.flexbox === false) {
            self.menuScrollState();
        }
        else {

            // timeout for callback on scroll end
            if (self.menuScrollTimeout) {
                clearTimeout(self.menuScrollTimeout);
                self.menuScrollTimeout = null;
            }
            self.menuScrollTimeout = setTimeout(self.menuScrollState, 200);
        }
    };
    this.menuScrollState = function () {

        var self = app.components.menu || this,

         pos = self.$hostList.scrollLeft(),
            hostElement = self.$hostList[0],
            maxWidth = hostElement.scrollWidth - hostElement.clientWidth;

        self.$prevBtn.toggleClass('disabled', pos == 0);
        self.$nextBtn.toggleClass('disabled', pos == maxWidth);

    };

    // act
    this.init(links);
};

// main
function SharePlusOnLoad() {

    // bindings
    $("#navSearch").submit(app.handlers.search);

    // load & initialize
    app.data.siteUrl = SPlus.Context.Current.webUrl;
    app.handlers.loadLinks();
    app.handlers.loadOverview();
}

// DEBUG
//$(document).ready(function () {

//    // MOCK

//    SPlus = { Context: { Current: { webUrl: 'http://google.com' } } };

//    app.handlers.loadLinks = function () {

//        for (var i = 0; i < 15; i++) {
//            app.data.links.push(new Link('Menu Item -  ' + i, 'http://google.com'));
//        }

//        // init menu
//        app.handlers.initMenu();
//    };
//    app.handlers.loadOverview = function () {
//        var $overview = $("#overview-description", "main"),
//                $content = $(app.data.overview.defaultContent.replace('[site]', SPlus.Context.Current.webTitle || 'Community'));
//        $overview.empty().append($content);
//    };

//    // init
//    SharePlusOnLoad();
//})

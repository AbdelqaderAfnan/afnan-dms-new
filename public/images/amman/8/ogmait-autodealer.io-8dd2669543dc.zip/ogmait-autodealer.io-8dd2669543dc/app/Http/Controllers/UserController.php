<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\User;
use DB;
use Hash;

class UserController extends Controller
{
    /**
     * Display a listing of the users.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $data = User::where('status', '<>', 'deleted')->orderBy('id', 'DESC')->paginate(5);
        return view('portal.users.index', compact('data'))
            ->with('i', ($request->input('page', 1) - 1) * 5);
    }

    /**
     * Show the form for creating a new user.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('portal.users.create');
    }

    /**
     * Store a newly created user in storage.
     *
     * @param Request $request
     * @return Response
     * @throws \Illuminate\Validation\ValidationException
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'first_name' => 'required',
            'last_name' => 'required',
            'email' => 'required',
            'password' => 'required|same:confirm-password',
            'role' => 'required',
            'phone' => 'required'
        ]);

        $input = $request->all();
        $input['password'] = Hash::make($input['password']);
        $input['status'] = 'active';
        $old_user = User::where('email', $input['email'])->first();

        if ($old_user != NULL && $old_user->status == 'deleted') {

            $old_user->update($input);

        } elseif ($old_user != NULL && $old_user->status == 'active') {

            return redirect()->route('users.create')
                ->with('failed', 'User Already Exist');

        } else {
            User::create($input);
        }

        return redirect()->route('users.index')
            ->with('success', 'User created successfully');
    }

    /**
     * Display the specified user.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $user = User::find($id);
        return view('users.show', compact('user'));
    }

    /**
     * Show the form for editing the specified user.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $user = User::find($id);
        return view('portal.users.edit', compact('user'));
    }

    /**
     * Update the specified user in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param int $id
     * @return \Illuminate\Http\Response
     * @throws \Illuminate\Validation\ValidationException
     */
    public function update(Request $request, $id)
    {
        $this->validate($request, [
            'first_name' => 'required',
            'last_name' => 'required',
            'email' => 'required|email|unique:users,email,' . $id,
            'phone' => 'required',
            'role' => 'required',
        ]);

        $input = $request->all();
        $user = User::find($id);
        $user->update($input);

        return redirect()->route('users.index')
            ->with('alert-success', 'User updated successfully');
    }

    /**
     * Remove the specified user from storage.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $count = DB::table('users')->where('role', 'owner')->count();
        $user = User::find($id);

        if ($user->role == 'owner' && $count == 1) {
            return redirect()->route('users.index')
                ->with('alert-danger', 'You can not remove the Owner account!');
        } elseif ($user->email == \Auth::user()->email) {
            return redirect()->route('users.index')
                ->with('alert-danger', 'You can not remover your account!');
        } else {
            $user->where('id', $user->id)
                ->update(['status' => 'deleted']);
            // User::find($id)->delete();
            return redirect()->route('users.index')
                ->with('alert-success', 'User deleted successfully!');
        }
    }

    public function profile(User $user)
    {

        $user = \Auth::user();
        return view('portal.profile', compact('user'));
    }

    public function update_profile(User $user, Request $request)
    {
        $this->validate(request(), [
            'first_name' => 'required',
            'last_name' => 'required',
            'email' => 'required|email',
            'phone' => 'required',
        ]);

        $input = $request->all();
        $user = User::find($user->id);
        $user->update($input);


        return redirect()->route('profile', $user->id)
            ->with('alert-success', 'Profile updated successfully!');

    }

}


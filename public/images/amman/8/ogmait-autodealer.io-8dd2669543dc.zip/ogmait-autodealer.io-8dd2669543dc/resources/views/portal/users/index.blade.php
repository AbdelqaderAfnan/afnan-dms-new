@extends('portal.layouts.app')

@section('content')
    <div class="row">
        <div class="col">
            <div class="flash-message">
                @foreach (['danger', 'warning', 'success', 'info'] as $msg)
                    @if(Session::has('alert-' . $msg))
                        <p class="alert alert-{{ $msg }}">{{ Session::get('alert-' . $msg) }}</p>
                    @endif
                @endforeach
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col">
            <ul class="nav">
                <li class="nav-item">
                    <a class="nav-link active" href="{{ route('users.create') }}">Add New User</a>
                </li>
            </ul>
        </div>
    </div>
    <div class="row">
        <div class="col">
            @foreach($data as $user)
                <div class="row">
                    <div class="col">
                        {{ $user->first_name }} {{ $user->last_name }} | {{ $user->email }} | {{ $user->phone }} | {{ $user->status }}
                    </div>
                    <div class="col-sm text-right">
                        <a href="{{ route('users.edit', $user->id ) }}">Edit</a>
                    </div>
                </div>
                <hr>

            @endforeach

        </div>
@endsection

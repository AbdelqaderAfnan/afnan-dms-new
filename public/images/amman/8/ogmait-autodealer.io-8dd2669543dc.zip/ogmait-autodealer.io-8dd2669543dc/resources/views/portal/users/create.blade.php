@extends('portal.layouts.app')

@section('content')
    <div class="">
        <div class="row">
            <div class="col">

                <h3>Create New User</h3>
                @if(count($errors) > 0)
                    <div class="alert alert-danger">
                        <strong>Whoops!</strong> There were some problems with your input.<br><br>
                        <ul>
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                @endif
                <form method="POST" action="{{ route('users.store') }}">
                    @csrf
                    <div class="form-group">
                        <strong>First Name:</strong>
                        <input type="text" name="first_name" value="{{ old('first_name') }}" placeholder="First Name"
                               class="form-control">
                    </div>
                    <div class="form-group">
                        <strong>Last Name:</strong>
                        <input type="text" name="last_name" value="{{ old('last_name') }}" placeholder="Last Name"
                               class="form-control">
                    </div>

                    <div class="form-group">
                        <strong>Email:</strong>
                        <input type="email" name="email" value="{{ old('email') }}" placeholder="Email Address "
                               class="form-control" required>
                        <span id="error_email"></span>
                    </div>

                    <div class="form-group">
                        <strong>Phone:</strong>
                        <input type="number" name="phone" value="{{ old('phone') }}" placeholder="Phone Number"
                               class="form-control" required>
                    </div>

                    <div class="form-group">
                        <strong>Password:</strong>
                        <input type="password" name="password" placeholder="Password" class="form-control" required>
                    </div>

                    <div class="form-group">
                        <strong>Confirm Password:</strong>
                        <input type="password" name="confirm-password" placeholder="Confirm Password"
                               class="form-control" required>
                    </div>

                    <div class="form-group">
                        <strong>Role:</strong>
                        <select class="form-control" name="role" value="{{ old('role') }}" required>
                            <option value="admin">Admin</option>
                            <option value="user">User</option>
                        </select>
                    </div>

                    <div class="col text-center">
                        <button id="submit" type="submit" class="btn btn-primary">Submit</button>
                        <a class="btn btn-primary" href="{{ route('users.index') }}"> Back</a>
                    </div>
                </form>
            </div>
        </div>
@endsection

@extends('portal.layouts.app')

@section('content')

    <div class="row">
        <div class="col">

            <img src="{{ Auth::user()->gravatar }}" class="rounded-circle">

            <h3>Edit User</h3>
            @if(count($errors) > 0)
                <div class="alert alert-danger">
                    <strong>Whoops!</strong> There were some problems with your input.<br><br>
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <form method="POST" action="{{route('users.update', $user->id )}}">
                @csrf
                @method('PUT')

                <div class="form-group">
                    <strong>First Name:</strong>
                    <input type="text" name="first_name" value="{{ old('first_name') }}" placeholder="First Name"
                           class="form-control">
                </div>
                <div class="form-group">
                    <strong>Last Name:</strong>
                    <input type="text" name="last_name" value="{{ old('last_name') }}" placeholder="Last Name"
                           class="form-control">
                </div>

                <div class="form-group">
                    <strong>Email:</strong>
                    <input type="text" name="email" value="{{$user->email}}" placeholder="Email" class="form-control"
                           required="">
                    <span id="error_email"></span>
                </div>

                <div class="form-group">
                    <strong>Phone:</strong>
                    <input type="number" name="phone" value="{{$user->phone}}" placeholder="Phone" class="form-control"
                           required="">
                </div>

                <div class="form-group">
                    <strong>Role:</strong>
                    <select class="form-control" name="role" required>
                        <option value="{{$user->role}}" selected>{{ ucfirst(trans($user->role)) }}</option>
                        <option value="admin">Admin</option>
                        <option value="user">User</option>

                    </select>
                </div>

                <button type="submit" class="btn btn-primary">Submit</button>
                <a class="btn btn-primary" href="{{ route('users.index') }}"> Back</a>
            </form>

            <form method="POST" action="{{route('users.destroy',$user->id)}}" class="mr-0">
                @csrf
                @method('DELETE')
                <button type="submit" onclick="return confirm('Please confirm you want to delete!')"
                        class="btn btn-danger">Delete
                </button>
            </form>
        </div>
@endsection
